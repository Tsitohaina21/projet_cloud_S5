import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import signalementService from '../services/signalementService';
import SignalementList from '../components/SignalementList';

const DashboardPage = () => {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [signalements, setSignalements] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user?.role !== 'manager') {
      navigate('/');
    } else {
      loadSignalements();
    }
  }, [user, navigate]);

  const loadSignalements = async () => {
    setIsLoading(true);
    console.log('📋 [DashboardPage] Loading signalements...');
    const data = await signalementService.getAllSignalements();
    console.log('📋 [DashboardPage] Loaded data:', data);
    setSignalements(data || []);
    setIsLoading(false);
  };

  return (
    <div className="page-shell">
      <div className="container py-4">
        <div className="page-header">
          <div>
            <h1 className="page-title">Gestion des signalements</h1>
            <p className="page-subtitle">Modifiez et supervisez les travaux en cours</p>
          </div>
        </div>

        <div className="card panel-card">
          <div className="card-body">
            {isLoading ? (
              <div className="text-center text-muted py-4">Chargement...</div>
            ) : (
              <SignalementList
                signalements={signalements}
                isManager={true}
                onUpdate={loadSignalements}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
