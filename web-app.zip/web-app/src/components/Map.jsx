import React, { useEffect } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const MapComponent = ({ signalements, onSignalementSelect, className = '' }) => {
  const mapContainer = React.useRef(null);
  const map = React.useRef(null);
  const markersLayer = React.useRef(null);

  useEffect(() => {
    if (mapContainer.current && !map.current) {
      // Initialize map centered on Antananarivo
      map.current = L.map(mapContainer.current).setView([-18.8792, 47.5079], 12);

      // Add tile layer
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(map.current);

      // Create layer group for markers
      markersLayer.current = L.layerGroup().addTo(map.current);
    }

    return () => {
      // Cleanup
      if (markersLayer.current && map.current) {
        map.current.removeLayer(markersLayer.current);
      }
    };
  }, []);

  // Update markers when signalements change
  useEffect(() => {
    if (!map.current || !markersLayer.current) return;

    console.log('🗺️ Updating markers with signalements:', signalements);
    console.log('🗺️ Number of signalements:', signalements.length);

    // Clear existing markers
    markersLayer.current.clearLayers();

    if (!signalements || signalements.length === 0) {
      console.warn('⚠️ No signalements to display on map');
      return;
    }

    // Add new markers
    signalements.forEach((signalement) => {
      console.log('📍 Processing signalement:', {
        id: signalement.id,
        latitude: signalement.latitude,
        longitude: signalement.longitude,
        latType: typeof signalement.latitude,
        lonType: typeof signalement.longitude,
        isValidLat: !isNaN(signalement.latitude),
        isValidLon: !isNaN(signalement.longitude)
      });

      // Validate coordinates
      if (!signalement.latitude || !signalement.longitude || 
          isNaN(signalement.latitude) || isNaN(signalement.longitude)) {
        console.warn('⚠️ Skipping signalement with invalid coordinates:', signalement);
        return;
      }

      const color =
        signalement.status === 'nouveau'
          ? 'red'
          : signalement.status === 'en_cours'
            ? 'orange'
            : 'green';

      const marker = L.divIcon({
        html: `<div class="signal-marker" style="width: 50px; height: 50px; background-color: ${color}; border: 5px solid white; border-radius: 50%; box-shadow: 0 0 0 2px ${color}, 0 4px 8px rgba(0,0,0,0.4), 0 0 15px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; cursor: pointer; font-weight: bold; color: white; font-size: 24px;">
          ${signalement.status === 'nouveau' ? '🔴' : signalement.status === 'en_cours' ? '🟠' : '🟢'}
        </div>`,
        className: 'marker-icon',
        iconSize: [50, 50],
        iconAnchor: [25, 25],
        popupAnchor: [0, -25],
      });
      
      const leafletMarker = L.marker(
        [signalement.latitude, signalement.longitude],
        { icon: marker }
      )
        .bindPopup(
          `<div style="min-width: 220px; font-size: 13px;">
            <h5 style="margin: 0 0 10px 0; font-weight: bold;">Signalement #${signalement.id}</h5>
            <p style="margin: 5px 0;"><strong>📍 Entreprise:</strong> ${signalement.company || 'N/A'}</p>
            <p style="margin: 5px 0;"><strong>📊 Status:</strong> ${signalement.status === 'nouveau' ? '🔴 Nouveau' : signalement.status === 'en_cours' ? '🟠 En cours' : '🟢 Terminé'}</p>
            <p style="margin: 5px 0;"><strong>📏 Surface:</strong> ${(signalement.surface || 0).toFixed(2)} m²</p>
            <p style="margin: 5px 0;"><strong>💰 Budget:</strong> ${(signalement.budget || 0).toLocaleString()} Ar</p>
            <p style="margin: 5px 0;"><strong>📅 Date:</strong> ${new Date(signalement.createdDate).toLocaleDateString('fr-FR')}</p>
          </div>`
        )
        .on('click', () => {
          if (onSignalementSelect) {
            onSignalementSelect(signalement);
          }
        });

      markersLayer.current.addLayer(leafletMarker);
      console.log('✅ Added marker for signalement #' + signalement.id);
    });

    console.log('✅ Total markers added:', markersLayer.current.getLayers().length);
  }, [signalements, onSignalementSelect]);

  return (
    <div
      ref={mapContainer}
      className={`w-100 h-100 rounded-3 ${className}`}
      style={{ minHeight: '400px' }}
    />
  );
};

export default MapComponent;
